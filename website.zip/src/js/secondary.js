const max = 10;
for (let i = 0; i < max; i += 1) {  
  console.log(i);
}
